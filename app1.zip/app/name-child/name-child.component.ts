import { Component, OnInit ,Input, Output,EventEmitter} from '@angular/core';

@Component({
  selector: 'app-name-child',
  templateUrl: './name-child.component.html',
  styleUrls: ['./name-child.component.css']
})
export class NameChildComponent implements OnInit {
	@Input() public msg:string;
	msg2="CTS";
	@Output() event:EventEmitter<string>
	=new EventEmitter();
	send(){
		this.event.emit(this.msg2);
	}
  constructor() { }

  ngOnInit() {
  	console.log(this.msg);
  }

}
