import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BetterHighlightoneComponent } from './better-highlightone.component';

describe('BetterHighlightoneComponent', () => {
  let component: BetterHighlightoneComponent;
  let fixture: ComponentFixture<BetterHighlightoneComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BetterHighlightoneComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BetterHighlightoneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
