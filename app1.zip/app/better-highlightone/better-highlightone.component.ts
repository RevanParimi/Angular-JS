import { 
	Component,
	OnInit,
	Directive,
	Renderer2,
	ElementRef,
	HostListener,
	HostBinding,
	Input
	 } from '@angular/core';

@Directive({
	selector: '[appBetterHighlightone],app-better-highlightone'
})

export class BetterHighlightoneComponent implements OnInit {
	@Input() defaultColor: string = 'transparent';
	@Input('appBetterHighlightone') highlightColor :string = 'blue';
	@HostBinding('style.backgroundColor') backgroundColor: string ='black';

constructor (private elRef: ElementRef,private renderer: Renderer2){ }

  ngOnInit() {
  	this.backgroundColor = this.defaultColor;
  }
  @HostListener('mouseenter') mouseover(eventData: Event){
  	this.backgroundColor = this.highlightColor;
  }

  @HostListener('mouseleave') mouseleave(eventData: Event){
  	this.backgroundColor = this.defaultColor;

  }
  @HostListener('click') onclick(eventData: Event){
  	this.backgroundColor = this.backgroundColor;

  }
 
}




  

