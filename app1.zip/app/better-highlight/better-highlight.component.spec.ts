import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BetterHighlightComponent } from './better-highlight.component';

describe('BetterHighlightComponent', () => {
  let component: BetterHighlightComponent;
  let fixture: ComponentFixture<BetterHighlightComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BetterHighlightComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BetterHighlightComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
