import { Injectable } from '@angular/core';

@Injectable()
export class DataserviceService {
constructor() { }
cars=["honda","Maruthi"];
myData(){
	return "this is my car";
  }

}


