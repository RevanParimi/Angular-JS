import { Directive,ElementRef, OnInit } from '@angular/core';

@Directive({
  selector: '[appBasicHighlight1]'
})
export class BasicHighlight1Component implements OnInit {

  constructor(private elementRef: ElementRef) { }

  ngOnInit() {
  	this.elementRef.nativeElement.style.color = 'darkblue';
  }

}
