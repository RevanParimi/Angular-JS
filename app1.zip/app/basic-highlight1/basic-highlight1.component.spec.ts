import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BasicHighlight1Component } from './basic-highlight1.component';

describe('BasicHighlight1Component', () => {
  let component: BasicHighlight1Component;
  let fixture: ComponentFixture<BasicHighlight1Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BasicHighlight1Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BasicHighlight1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
