import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-application',
  template: `
  <button type="button" (click)="toggleExists()">Toggle Component</button>
  <hr>
  <app-server *ngIf="exists">
  Hello
  </app-server>
  `
  // styleUrls: ['./application.component.css']
})
export class ApplicationComponent implements OnInit {
	exists=true;

  constructor() { }

  ngOnInit() {
  }
  toggleExists(){
  	this.exists = !this.exists;
  }
}
