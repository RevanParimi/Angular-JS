import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-asses1',
  templateUrl: './asses1.component.html',
  styleUrls: ['./asses1.component.css']
})
export class Asses1Component implements OnInit {


assesone(){
	
}

// Addition()
// {
// x=parseFloat(calc.value1.value);
// y=parseFloat(calc.value2.value);
// z=(x+y);
// alert("The Addition result is"+z);
// calc.value3.value=z
// }
// function Subtraction()
// {
// var x,y,z;
// x=calc.value1.value;
// y=calc.value2.value;
// z=x-y;
// alert("The subtraction result is "+z);
// calc.value3.value=z
// }
// function Multiplication()
// {
// var x,y,z;
// x=calc.value1.value;
// y=calc.value2.value;
// z=x*y;
// alert("The Multiplication result is "+z);
// calc.value3.value=z
// }
// function Division()
// {
// var x,y,z;
// x=calc.value1.value;
// y=calc.value2.value;
// z=x/y;
// alert("The subtraction result is "+z);
// calc.value3.value=z
// }
  constructor() { 

   }

  ngOnInit() {
  }

}
