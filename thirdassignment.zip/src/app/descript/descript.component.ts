import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-descript',
  templateUrl: './descript.component.html',
  styleUrls: ['./descript.component.css']
})
export class DescriptComponent implements OnInit {
// data1=["Revan","23","Chennai","CTS","IT"];
// data2=["Revan","23","Chennai","CTS","IT"];
// data3=["Revan","23","Chennai","CTS","IT"];
// data4=["Revan","23","Chennai","CTS","IT"];
// data5=["Revan","23","Chennai","CTS","IT"];


  constructor() { }

  ngOnInit() {
  }

}
