import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {
data1=["Revan","23","Chennai","CTS","IT"];
data2=["Rithan","23","Chennai","CTS","IT"];
data3=["Rajesh","23","Chennai","CTS","IT"];
data4=["Sugumar","23","Chennai","CTS","IT"];
data5=["Deepa","23","Chennai","CTS","IT"];

  constructor() { }
}
