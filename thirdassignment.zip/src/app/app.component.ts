import { Component } from '@angular/core';
import { ServiceService } from './service.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
  name;
  id;
  city;
  company;
  branch;

constructor(private serv :ServiceService){

}
f1(){
	this.name=this.serv.data1[0];
	this.id=this.serv.data1[1];
	this.city=this.serv.data1[2];
	this.company=this.serv.data1[3];
	this.branch=this.serv.data1[4];
}
f2(){
	this.name=this.serv.data2[0];
	this.id=this.serv.data2[1];
	this.city=this.serv.data2[2];
	this.company=this.serv.data2[3];
	this.branch=this.serv.data2[4];
}
f3(){
	this.name=this.serv.data3[0];
	this.id=this.serv.data3[1];
	this.city=this.serv.data3[2];
	this.company=this.serv.data3[3];
	this.branch=this.serv.data3[4];
}
f4(){
	this.name=this.serv.data4[0];
	this.id=this.serv.data4[1];
	this.city=this.serv.data4[2];
	this.company=this.serv.data4[3];
	this.branch=this.serv.data4[4];
}
f5(){
	this.name=this.serv.data5[0];
	this.id=this.serv.data5[1];
	this.city=this.serv.data5[2];
	this.company=this.serv.data5[3];
	this.branch=this.serv.data5[4];
}
}