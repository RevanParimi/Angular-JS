import { BordercolorDirective } from './bordercolor.directive';

describe('BordercolorDirective', () => {
  it('should create an instance', () => {
    const directive = new BordercolorDirective();
    expect(directive).toBeTruthy();
  });
});
