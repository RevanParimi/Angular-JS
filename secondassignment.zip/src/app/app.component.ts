import { Component } from '@angular/core';
// import { DataserviceService } from './dataservice.service';
@Component({
  selector: 'app-root',
templateUrl: './app.component.html', 
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  oddNumbers = [1,3,5];
  evenNumbers = [2,4];
  onlyOdd = false;
  userName="";
  passWord="";
  valid="";
  page0=true;
  page1=false;
  page2=false;
  page3=false;
  x="";
  y="";
  z="";
  a="Inception";
	b="FightClub";
	c="WreckItRalph";
	d="Mission Impossible";
	image1="../assets/imag_one.jpg";
	image2="../assets/image_two.jpg";
	image3="../assets/image_three.jpg";
	image4="../assets/image_four.jpg";
  
 validation(){
 	if(this.userName==this.passWord){
 		this.valid="Good Morning "+this.userName;
    this.page0=false;
    this.page1=true;
 	}
 	else{
 		this.valid="wrong details";
 	}
 }
 validation1(){
 		
    this.page1=false;
    this.page2=true;
 	}


function f1(){
 return this.z=this.x+this.y;		
}
function f1(){
 return this.z=this.x-this.y;		
}		
function f1(){
 return this.z=this.x*this.y;		
}
function f1(){
 return this.z=this.x/this.y;		
}
function f1(){
 return this.z=this.x%this.y;		
}



 }

