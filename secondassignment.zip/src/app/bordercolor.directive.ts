
import { Component,
	OnInit,
	Directive,
	Renderer2,
	ElementRef,
	HostListener,
	HostBinding,
	Input } from '@angular/core';
@Directive({
  selector: '[appBordercolor]'
})


export class BordercolorDirective {
	@Input() defaultColor: string = 'transparent';
	@Input('appBordercolor') highlightColor :string = 'blue';
	@HostBinding('style.borderColor') borderColor: string ='black';

	a="Inception";
	b="FightClub";
	c="WreckItRalph";
	d="Mission Impossible";


  constructor(private elRef: ElementRef,private renderer: Renderer2) { }

  ngOnInit() {
  	this.borderColor = this.defaultColor;
  }
  @HostListener('mouseenter') mouseover(eventData: Event){
  	this.borderColor = "red";
  }

  @HostListener('mouseleave') mouseleave(eventData: Event){
  	this.borderColor = this.defaultColor;

  }
  @HostListener('click') onclick(eventData: Event){
  	this.borderColor = "red";

  }

  }